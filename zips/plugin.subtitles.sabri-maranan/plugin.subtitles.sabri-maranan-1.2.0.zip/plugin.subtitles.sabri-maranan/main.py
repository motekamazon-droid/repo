#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import urllib.request
import urllib.error
import tempfile

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# Get plugin handle and params
plugin_handle = int(sys.argv[1])
params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))


class SabriMarananSubtitleService:
    def __init__(self):
        self.repo_base = "https://raw.githubusercontent.com/motekamazon-droid/repo/main/en/s01"
        # All available subtitles
        self.subtitles = {
            1: ("Babysitters Big Brother", "sabri_maranan_s1e01_english-Babysitters_Big_Brother.srt"),
            2: ("Huge Mistake", "sabri_maranan_s1e02_english-Huge_Mistake.srt"),
            3: ("Happy Itzik", "sabri_maranan_s1e03_english-Happy_Itzik.srt"),
            4: ("Holiday Evening", "sabri_maranan_s1e04_english-Holiday_Evening.srt"),
            5: ("Saturday Morning", "sabri_maranan_s1e05_english-Saturday_Morning_Hard_Day.srt"),
            6: ("Stockholm Syndrome", "sabri_maranan_s1e06_english-Stockholm_Syndrome.srt"),
            7: ("No Help", "sabri_maranan_s1e07_english-No_Help.srt"),
            8: ("Ill Go to the Forest", "sabri_maranan_s1e08_english-Ill_Go_to_the_Forest.srt"),
            9: ("Five Minutes", "sabri_maranan_s1e09_english-A_Matter_of_Five_Minutes.srt"),
            10: ("Early Wedding", "sabri_maranan_s1e10_english-Early_Wedding.srt"),
            11: ("Lice", "sabri_maranan_s1e11_english-Lice.srt"),
            12: ("Head of the Year", "sabri_maranan_s1e12_english-On_the_Head_of_the_Year.srt"),
            13: ("Painting", "sabri_maranan_s1e13_english-Painting.srt"),
            14: ("Hasson Towers", "sabri_maranan_s1e14_english-Hasson_Towers.srt"),
            15: ("Hammer and Nail", "sabri_maranan_s1e15_english-Hammer_and_Nail.srt"),
            16: ("Camping", "sabri_maranan_s1e16_english-Camping.srt"),
            17: ("French Lessons", "sabri_maranan_s1e17_english-French_Lessons.srt"),
        }

    def log(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] {msg}", xbmc.LOGINFO)

    def search(self):
        """List all available subtitles"""
        try:
            self.log("Listing available subtitles...")

            for ep_num in sorted(self.subtitles.keys()):
                title, filename = self.subtitles[ep_num]
                label = f"E{ep_num:02d} {title}"

                listitem = xbmcgui.ListItem(label="English", label2=label)
                listitem.setArt({'icon': '5', 'thumb': 'en'})
                listitem.setProperty('sync', 'false')
                listitem.setProperty('hearing_imp', 'false')

                # URL encodes the filename so download action can retrieve it
                url = f"plugin://plugin.subtitles.sabri-maranan/?action=download&filename={urllib.parse.quote(filename)}"

                xbmcplugin.addDirectoryItem(
                    handle=plugin_handle,
                    url=url,
                    listitem=listitem,
                    isFolder=False
                )
                self.log(f"Added: {label}")

            xbmcplugin.endOfDirectory(plugin_handle)
            self.log("Subtitle list complete")

        except Exception as e:
            self.log(f"ERROR in search: {str(e)}")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}")
            xbmcplugin.endOfDirectory(plugin_handle)

    def download(self, filename):
        """Download selected subtitle and return local path to Kodi"""
        try:
            url = f"{self.repo_base}/{filename}"
            self.log(f"Downloading: {url}")

            # Use Kodi temp directory
            temp_dir = os.path.join(
                xbmcvfs.translatePath('special://temp'),
                'sabri_subs'
            )
            os.makedirs(temp_dir, exist_ok=True)

            local_path = os.path.join(temp_dir, filename)
            self.log(f"Saving to: {local_path}")

            # Download from GitHub
            urllib.request.urlretrieve(url, local_path)
            self.log(f"Downloaded OK: {local_path}")

            # Return the local path to Kodi
            listitem = xbmcgui.ListItem(label=local_path)
            xbmcplugin.addDirectoryItem(
                handle=plugin_handle,
                url=local_path,
                listitem=listitem,
                isFolder=False
            )
            xbmcplugin.endOfDirectory(plugin_handle)
            self.log(f"Subtitle ready: {local_path}")

        except Exception as e:
            self.log(f"ERROR downloading: {str(e)}")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}")
            xbmcplugin.endOfDirectory(plugin_handle)

    def run(self):
        action = params.get('action', 'search')
        self.log(f"Action: {action}, Params: {params}")

        if action == 'search' or action == 'manualsearch':
            self.search()
        elif action == 'download':
            filename = params.get('filename', '')
            if filename:
                self.download(urllib.parse.unquote(filename))
            else:
                self.log("ERROR: No filename provided for download")
                xbmcplugin.endOfDirectory(plugin_handle)
        else:
            self.log(f"Unknown action: {action}")
            self.search()


if __name__ == '__main__':
    service = SabriMarananSubtitleService()
    service.run()
