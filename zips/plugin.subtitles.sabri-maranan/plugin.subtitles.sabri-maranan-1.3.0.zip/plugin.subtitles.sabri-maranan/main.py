#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import sys
import os
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

# Get plugin handle and params
plugin_handle = int(sys.argv[1])
params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))


class SabriMarananSubtitleService:
    def __init__(self):
        self.repo_base = "https://raw.githubusercontent.com/motekamazon-droid/repo/main/en/s01"
        # All available subtitles: ep_num -> (short_title, filename)
        self.subtitles = {
            1: ("Babysitters Big Brother", "sabri_maranan_s1e01_english-Babysitters_Big_Brother.srt"),
            2: ("Huge Mistake", "sabri_maranan_s1e02_english-Huge_Mistake.srt"),
            3: ("Happy Itzik", "sabri_maranan_s1e03_english-Happy_Itzik.srt"),
            4: ("Holiday Evening", "sabri_maranan_s1e04_english-Holiday_Evening.srt"),
            5: ("Saturday Morning", "sabri_maranan_s1e05_english-Saturday_Morning_Hard_Day.srt"),
            6: ("Stockholm Syndrome", "sabri_maranan_s1e06_english-Stockholm_Syndrome.srt"),
            7: ("No Help", "sabri_maranan_s1e07_english-No_Help.srt"),
            8: ("Ill Go to the Forest", "sabri_maranan_s1e08_english-Ill_Go_to_the_Forest.srt"),
            9: ("Five Minutes", "sabri_maranan_s1e09_english-A_Matter_of_Five_Minutes.srt"),
            10: ("Early Wedding", "sabri_maranan_s1e10_english-Early_Wedding.srt"),
            11: ("Lice", "sabri_maranan_s1e11_english-Lice.srt"),
            12: ("Head of the Year", "sabri_maranan_s1e12_english-On_the_Head_of_the_Year.srt"),
            13: ("Painting", "sabri_maranan_s1e13_english-Painting.srt"),
            14: ("Hasson Towers", "sabri_maranan_s1e14_english-Hasson_Towers.srt"),
            15: ("Hammer and Nail", "sabri_maranan_s1e15_english-Hammer_and_Nail.srt"),
            16: ("Camping", "sabri_maranan_s1e16_english-Camping.srt"),
            17: ("French Lessons", "sabri_maranan_s1e17_english-French_Lessons.srt"),
        }

    def log(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] {msg}", xbmc.LOGINFO)

    def detect_episode(self):
        """Try to detect which episode is currently playing"""
        try:
            player = xbmc.Player()
            if not player.isPlaying():
                self.log("No video playing")
                return None

            playing_file = player.getPlayingFile()
            self.log(f"Playing file: {playing_file}")

            # Pattern 1: Streaming URL like Sabri_Maranan_04_240811
            match = re.search(r'Sabri_Maranan_(\d{2})', playing_file, re.IGNORECASE)
            if match:
                ep = int(match.group(1))
                self.log(f"Detected episode {ep} from streaming URL")
                return ep

            # Pattern 2: Standard S01E04 or s1e04 format
            match = re.search(r'[Ss]\d{1,2}[Ee](\d{1,2})', playing_file)
            if match:
                ep = int(match.group(1))
                self.log(f"Detected episode {ep} from S01E format")
                return ep

            # Pattern 3: Hebrew פרק in URL-encoded plugin name (%D7%A4%D7%A8%D7%A7)
            decoded = urllib.parse.unquote(playing_file)
            match = re.search(r'\u05E4\u05E8\u05E7\s*(\d{1,2})', decoded)
            if match:
                ep = int(match.group(1))
                self.log(f"Detected episode {ep} from Hebrew text")
                return ep

            # Pattern 4: episode/ep/e followed by number
            match = re.search(r'(?:episode|ep|e)[\s._-]*(\d{1,2})', playing_file, re.IGNORECASE)
            if match:
                ep = int(match.group(1))
                self.log(f"Detected episode {ep} from episode/ep pattern")
                return ep

            self.log("Could not detect episode number")
            return None

        except Exception as e:
            self.log(f"Error detecting episode: {str(e)}")
            return None

    def add_subtitle_item(self, ep_num, title, filename, is_auto=False):
        """Add a single subtitle item to the list"""
        if is_auto:
            label2 = f"[AUTO] E{ep_num:02d} {title}"
        else:
            label2 = f"E{ep_num:02d} {title}"

        listitem = xbmcgui.ListItem(label="English", label2=label2)
        listitem.setArt({'icon': '5', 'thumb': 'en'})
        listitem.setProperty('sync', 'true' if is_auto else 'false')
        listitem.setProperty('hearing_imp', 'false')

        url = f"plugin://plugin.subtitles.sabri-maranan/?action=download&filename={urllib.parse.quote(filename)}"

        xbmcplugin.addDirectoryItem(
            handle=plugin_handle,
            url=url,
            listitem=listitem,
            isFolder=False
        )

    def search(self):
        """List subtitles - auto-detected episode first, then all others"""
        try:
            self.log("Search mode - detecting episode...")
            detected_ep = self.detect_episode()

            if detected_ep and detected_ep in self.subtitles:
                # Show detected episode first with [AUTO] tag
                title, filename = self.subtitles[detected_ep]
                self.add_subtitle_item(detected_ep, title, filename, is_auto=True)
                self.log(f"Auto-detected: E{detected_ep:02d} {title}")

            # Show all episodes (skip detected one since it's already first)
            for ep_num in sorted(self.subtitles.keys()):
                if ep_num == detected_ep:
                    continue
                title, filename = self.subtitles[ep_num]
                self.add_subtitle_item(ep_num, title, filename)

            xbmcplugin.endOfDirectory(plugin_handle)
            self.log("Subtitle list complete")

        except Exception as e:
            self.log(f"ERROR in search: {str(e)}")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}")
            xbmcplugin.endOfDirectory(plugin_handle)

    def download(self, filename):
        """Download selected subtitle and return local path to Kodi"""
        try:
            url = f"{self.repo_base}/{filename}"
            self.log(f"Downloading: {url}")

            # Use Kodi temp directory
            temp_dir = os.path.join(
                xbmcvfs.translatePath('special://temp'),
                'sabri_subs'
            )
            os.makedirs(temp_dir, exist_ok=True)

            local_path = os.path.join(temp_dir, filename)
            self.log(f"Saving to: {local_path}")

            # Download from GitHub (always re-download, don't cache)
            urllib.request.urlretrieve(url, local_path)
            self.log(f"Downloaded OK: {local_path}")

            # Return the local path to Kodi
            listitem = xbmcgui.ListItem(label=local_path)
            xbmcplugin.addDirectoryItem(
                handle=plugin_handle,
                url=local_path,
                listitem=listitem,
                isFolder=False
            )
            xbmcplugin.endOfDirectory(plugin_handle)
            self.log(f"Subtitle ready: {local_path}")

        except Exception as e:
            self.log(f"ERROR downloading: {str(e)}")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}")
            xbmcplugin.endOfDirectory(plugin_handle)

    def run(self):
        action = params.get('action', 'search')
        self.log(f"Action: {action}, Params: {params}")

        if action in ('search', 'manualsearch'):
            self.search()
        elif action == 'download':
            filename = params.get('filename', '')
            if filename:
                self.download(urllib.parse.unquote(filename))
            else:
                self.log("ERROR: No filename provided for download")
                xbmcplugin.endOfDirectory(plugin_handle)
        else:
            self.log(f"Unknown action: {action}, defaulting to search")
            self.search()


if __name__ == '__main__':
    service = SabriMarananSubtitleService()
    service.run()
