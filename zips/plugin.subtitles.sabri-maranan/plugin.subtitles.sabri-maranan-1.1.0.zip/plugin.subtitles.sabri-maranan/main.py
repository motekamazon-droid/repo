#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse
import urllib.request
import urllib.error
import tempfile

import xbmc
import xbmcgui
import xbmcplugin

# Get plugin handle
plugin_handle = int(sys.argv[1])

class SabriMaryananSubtitleService:
    def __init__(self):
        self.repo_base = "https://raw.githubusercontent.com/motekamazon-droid/repo/main/en/s01"
        # All available subtitles
        self.subtitles = {
            1: "sabri_maranan_s1e01_english-Babysitters_Big_Brother.srt",
            2: "sabri_maranan_s1e02_english-Huge_Mistake.srt",
            3: "sabri_maranan_s1e03_english-Happy_Itzik.srt",
            4: "sabri_maranan_s1e04_english-Holiday_Evening.srt",
            5: "sabri_maranan_s1e05_english-Saturday_Morning_Hard_Day.srt",
            6: "sabri_maranan_s1e06_english-Stockholm_Syndrome.srt",
            7: "sabri_maranan_s1e07_english-No_Help.srt",
            8: "sabri_maranan_s1e08_english-Ill_Go_to_the_Forest.srt",
            9: "sabri_maranan_s1e09_english-A_Matter_of_Five_Minutes.srt",
            10: "sabri_maranan_s1e10_english-Early_Wedding.srt",
            11: "sabri_maranan_s1e11_english-Lice.srt",
            12: "sabri_maranan_s1e12_english-On_the_Head_of_the_Year.srt",
            13: "sabri_maranan_s1e13_english-Painting.srt",
            14: "sabri_maranan_s1e14_english-Hasson_Towers.srt",
            15: "sabri_maranan_s1e15_english-Hammer_and_Nail.srt",
            16: "sabri_maranan_s1e16_english-Camping.srt",
            17: "sabri_maranan_s1e17_english-French_Lessons.srt",
        }

    def log(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] {msg}", xbmc.LOGINFO)

    def download_subtitle(self, ep_num, filename):
        """Download subtitle file from GitHub"""
        try:
            url = f"{self.repo_base}/{filename}"
            self.log(f"Downloading: {url}")

            # Create temp directory
            temp_dir = os.path.join(tempfile.gettempdir(), 'kodi_subtitles_sabri')
            os.makedirs(temp_dir, exist_ok=True)

            # Download file
            local_path = os.path.join(temp_dir, filename)
            urllib.request.urlretrieve(url, local_path)

            self.log(f"✓ Downloaded to: {local_path}")
            return local_path

        except Exception as e:
            self.log(f"ERROR downloading: {str(e)}")
            return None

    def run(self):
        """List all available subtitles"""
        try:
            self.log("Listing available Sabri Maranan subtitles...")

            # Add all subtitles to the list
            for ep_num in sorted(self.subtitles.keys()):
                filename = self.subtitles[ep_num]
                label = f"Episode {ep_num}: {filename.split('english-')[1].replace('_', ' ').replace('.srt', '')}"

                # Create list item
                listitem = xbmcgui.ListItem(label=label)
                listitem.setArt({'icon': 'DefaultSubtitle.png'})

                # URL is just the local path (Kodi will download when selected)
                url = f"{self.repo_base}/{filename}"

                # Add to results
                xbmcplugin.addDirectoryItem(
                    handle=plugin_handle,
                    url=url,
                    listitem=listitem,
                    isFolder=False
                )

                self.log(f"Added: {label}")

            xbmcplugin.endOfDirectory(plugin_handle)
            self.log("✓ Subtitle list complete")

        except Exception as e:
            self.log(f"ERROR: {str(e)}")
            import traceback
            self.log(f"Traceback: {traceback.format_exc()}")
            xbmcplugin.endOfDirectory(plugin_handle)

if __name__ == '__main__':
    service = SabriMaryananSubtitleService()
    service.run()
