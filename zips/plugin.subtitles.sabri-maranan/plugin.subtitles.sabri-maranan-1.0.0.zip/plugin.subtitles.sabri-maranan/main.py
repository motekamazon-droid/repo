#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import urllib.parse

# Add lib directory to path
lib_path = os.path.join(os.path.dirname(__file__), 'lib')
sys.path.insert(0, lib_path)

import xbmc
import xbmcgui
import xbmcvfs
import xbmcplugin
from github_fetcher import GitHubSubtitleFetcher
from subtitle_matcher import SubtitleMatcher

# Get plugin handle
plugin_handle = int(sys.argv[1])

class SabriMaryananSubtitleService:
    def __init__(self):
        self.matcher = SubtitleMatcher()
        self.fetcher = GitHubSubtitleFetcher(
            repo_url="https://github.com/motekamazon-droid/repo",
            base_path="en/s01"
        )

    def log(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] {msg}", xbmc.LOGINFO)

    def log_error(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] ERROR: {msg}", xbmc.LOGERROR)

    def run(self):
        """Main entry point for subtitle service"""
        try:
            # Get parameters from Kodi
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

            # Get the filename being played
            filename = params.get('filename', '')
            if not filename:
                # Try to get from getPlayingFile
                player = xbmc.Player()
                if player.isPlaying():
                    filename = player.getPlayingFile()

            self.log(f"Subtitle service called for: {filename}")

            # Extract episode number
            ep_num = self.matcher.extract_episode_number(filename)
            if not ep_num:
                self.log_error(f"Could not extract episode number from: {filename}")
                xbmcplugin.endOfDirectory(plugin_handle)
                return

            self.log(f"Detected episode: {ep_num}")

            # Get subtitle filename
            srt_filename = self.matcher.get_subtitle_filename(ep_num)

            # Fetch subtitle
            subtitle_path = self.fetcher.fetch_subtitle(ep_num, srt_filename)

            if subtitle_path:
                # Add the subtitle as a search result
                self.log(f"✓ Found subtitle: {srt_filename}")

                # Create list item for the subtitle
                listitem = xbmcgui.ListItem(label=srt_filename)
                listitem.setArt({'icon': 'DefaultSubtitle.png'})

                # Return the subtitle file path
                url = subtitle_path
                xbmcplugin.addDirectoryItem(
                    handle=plugin_handle,
                    url=url,
                    listitem=listitem,
                    isFolder=False
                )
                self.log(f"Added subtitle result: {url}")
            else:
                self.log_error(f"Subtitle not found for episode {ep_num}")

            xbmcplugin.endOfDirectory(plugin_handle)

        except Exception as e:
            self.log_error(f"Exception: {str(e)}")
            import traceback
            self.log_error(f"Traceback: {traceback.format_exc()}")
            xbmcplugin.endOfDirectory(plugin_handle)

if __name__ == '__main__':
    service = SabriMaryananSubtitleService()
    service.run()
