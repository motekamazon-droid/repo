#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import tempfile
import urllib.request
import urllib.error
import xbmc
import xbmcvfs

class GitHubSubtitleFetcher:
    """Fetch subtitles from GitHub public repository"""

    def __init__(self, repo_url, base_path):
        """
        Initialize fetcher

        Args:
            repo_url: GitHub repo URL (e.g., https://github.com/user/repo)
            base_path: Path within repo (e.g., en/s01)
        """
        self.repo_url = repo_url.rstrip('/')
        self.base_path = base_path.strip('/')

        # Convert to raw GitHub URL
        # https://github.com/user/repo -> https://raw.githubusercontent.com/user/repo/main
        parts = self.repo_url.replace('https://', '').replace('http://', '').split('/')
        if len(parts) >= 2:
            self.raw_base = f"https://raw.githubusercontent.com/{parts[1]}/{parts[2]}/main"
        else:
            self.raw_base = self.repo_url

    def fetch_subtitle(self, episode_num, filename):
        """
        Fetch subtitle file from GitHub and save locally

        Args:
            episode_num: Episode number (e.g., 1, 12, 42)
            filename: SRT filename (e.g., sabri_maranan_s1e01_english-Title.srt)

        Returns:
            Path to downloaded subtitle, or None if not found
        """
        try:
            # Construct raw GitHub URL
            url = f"{self.raw_base}/{self.base_path}/{filename}"
            xbmc.log(f"[GitHubFetcher] Attempting to fetch: {url}", xbmc.LOGINFO)

            # Use Kodi temp directory for subtitle cache (works on all platforms)
            addon_home = xbmcvfs.translatePath('special://temp')
            temp_dir = os.path.join(addon_home, 'kodi_subtitles')
            xbmc.log(f"[GitHubFetcher] Using temp dir: {temp_dir}", xbmc.LOGINFO)
            os.makedirs(temp_dir, exist_ok=True)

            # Download file
            local_path = os.path.join(temp_dir, filename)

            # Skip if already cached
            if os.path.exists(local_path):
                xbmc.log(f"[GitHubFetcher] Subtitle cached: {local_path}", xbmc.LOGINFO)
                return local_path

            # Fetch from GitHub (no auth needed for public repos)
            xbmc.log(f"[GitHubFetcher] Downloading to: {local_path}", xbmc.LOGINFO)
            urllib.request.urlretrieve(url, local_path)
            xbmc.log(f"[GitHubFetcher] Successfully downloaded: {local_path}", xbmc.LOGINFO)

            return local_path

        except urllib.error.HTTPError as e:
            xbmc.log(f"[GitHubFetcher] HTTP Error {e.code} fetching {url}", xbmc.LOGERROR)
            if e.code == 404:
                return None  # File not found
            raise
        except Exception as e:
            xbmc.log(f"[GitHubFetcher] Error fetching subtitle from {url}: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"[GitHubFetcher] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return None

    def get_raw_url(self, filename):
        """Get the raw GitHub URL for a file"""
        return f"{self.raw_base}/{self.base_path}/{filename}"
