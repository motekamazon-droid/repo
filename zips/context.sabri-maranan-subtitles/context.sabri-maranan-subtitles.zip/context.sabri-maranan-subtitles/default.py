#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os

# Add lib directory to path
lib_path = os.path.join(os.path.dirname(__file__), 'lib')
sys.path.insert(0, lib_path)

import xbmc
import xbmcgui
from github_fetcher import GitHubSubtitleFetcher
from subtitle_matcher import SubtitleMatcher

class SabriMaryananContextMenu:
    def __init__(self):
        self.matcher = SubtitleMatcher()
        self.fetcher = GitHubSubtitleFetcher(
            repo_url="https://github.com/motekamazon-droid/repo",
            base_path="en/s01"
        )

    def log(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] {msg}", xbmc.LOGINFO)

    def log_error(self, msg):
        xbmc.log(f"[Sabri Maranan Subtitles] ERROR: {msg}", xbmc.LOGERROR)

    def show_dialog(self, title, message):
        dialog = xbmcgui.Dialog()
        dialog.ok(title, message)

    def run(self):
        """Download subtitle for currently selected item"""
        try:
            # Get the current playing file from the list item
            filename = xbmc.getInfoLabel('ListItem.FilenameAndPath')

            if not filename:
                self.show_dialog("Sabri Maranan Subtitles", "Could not get filename")
                return

            self.log(f"Context menu triggered for: {filename}")

            # Extract episode number
            ep_num = self.matcher.extract_episode_number(filename)
            if not ep_num:
                self.show_dialog("Sabri Maranan Subtitles", "Could not detect episode number")
                self.log_error(f"Could not extract episode number from: {filename}")
                return

            self.log(f"Detected episode: {ep_num}")

            # Get subtitle filename
            srt_filename = self.matcher.get_subtitle_filename(ep_num)

            # Show busy dialog
            pDialog = xbmcgui.DialogProgress()
            pDialog.create("Sabri Maranan Subtitles", f"Downloading subtitle for episode {ep_num}...")

            # Fetch subtitle
            subtitle_path = self.fetcher.fetch_subtitle(ep_num, srt_filename)
            pDialog.close()

            if subtitle_path:
                self.log(f"✓ Downloaded: {srt_filename}")
                self.show_dialog("Sabri Maranan Subtitles", f"✓ Downloaded subtitle for episode {ep_num}\n\nFile: {srt_filename}")
            else:
                self.log_error(f"Subtitle not found for episode {ep_num}")
                self.show_dialog("Sabri Maranan Subtitles", f"⚠ Subtitle not found for episode {ep_num}")

        except Exception as e:
            self.log_error(f"Exception: {str(e)}")
            import traceback
            self.log_error(f"Traceback: {traceback.format_exc()}")
            self.show_dialog("Sabri Maranan Subtitles", f"Error: {str(e)}")

if __name__ == '__main__':
    context = SabriMaryananContextMenu()
    context.run()
